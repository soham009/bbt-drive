from django.db import models

# Create your models here.
class file_object(models.Model)
  files = models.OneToOneField(files)

 class Member(models.Model):
        customuser = models.OneToOneField(customuser, on_delete=models.CASCADE)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now_add=True)

        def __str__(self):
        return str(self.pk) 