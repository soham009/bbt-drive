from django.contrib import admin

# Register your models here.
admin.register(file_object)
admin.register(Member)
class file_objectAdmin(admin.ModelAdmin, ExportCsvMixin):
class MemberAdmin(admin.ModelAdmin, ExportCsvMixin):