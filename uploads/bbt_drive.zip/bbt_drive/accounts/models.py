from django.db import models

# Create your models here.
class customuser(models.Model):
    admin = models.CharField(max_length=100)
    teammembers = models.CharField(max_length=100)
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now_add=True)
    
    class Member(models.Model):
        customuser = models.OneToOneField(customuser, on_delete=models.CASCADE)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now_add=True)
        

        def __str__(self):
        return str(self.pk) 



