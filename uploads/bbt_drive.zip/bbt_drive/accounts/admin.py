from django.contrib import admin

# Register your models here.
admin.register(customuser)
admin.register(Member)
class customuserAdmin(admin.ModelAdmin, ExportCsvMixin):
class MemberAdmin(admin.ModelAdmin, ExportCsvMixin):
    list_display = ('employee name', 'employee email', 'employee contact', )