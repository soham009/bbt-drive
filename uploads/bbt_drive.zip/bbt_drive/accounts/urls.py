from django.urls import include, path
from accounts import views
 
accounts = 'accounts'
 
urlpatterns = [
]
