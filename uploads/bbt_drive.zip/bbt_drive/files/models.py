from django.db import models

# Create your models here.
class files(models.Model):
    File_name= models.CharField(max_length=100)
class files(models.Model):
    # file will be uploaded to MEDIA_ROOT/uploads
    upload = models.FileField(upload_to='uploads/')
    # or...
    # file will be saved to MEDIA_ROOT/uploads/2015/01/30
    upload = models.FileField(upload_to='uploads/%Y/%m/%d/')
class  file_type(models.Model):
    file_type= models.CharField( max_length = 20) 
    choices=(
        (1,'public'),
         2,'private'),
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)
class publicfile(models.Model):  
    file_name    = models.CharField(max_length=20)  
    file_type    = models.CharField(max_length=100)  
class privatefile(models.Model):  
    file_name    = models.CharField(max_length=20)  
    file_type    = models.CharField(max_length=100)  
class user(models.Model)
    employeename  = models.CharField(max_length=100)  
    employeemail = models.CharField(max_length=15)  
    employeecontact = models.CharField(max_length=15)  
    

    
    

