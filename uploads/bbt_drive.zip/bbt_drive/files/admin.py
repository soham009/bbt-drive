from django.contrib import admin

# Register your models here.
admin.register(files)
class filesAdmin(admin.ModelAdmin, ExportCsvMixin):
    
