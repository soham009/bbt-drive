from django import forms
from .models import Category,user

class userForm(forms.ModelForm):
    category = GroupedModelChoiceField(
        queryset=Category.objects.exclude(parent=None), 
        choices_groupby='parent'
    )

    class Meta:
        model =user
        fields = ('employeename', 'email', 'contact')