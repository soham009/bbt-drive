from django.shortcuts import render
from django.forms import Modeluser 
 
def user(request):
    p =user(name="akshaya",email="akshayaleks@gmail.com",contact="9585651566")
    p.save()
    return render(request,'files/index.html')