from files import views
from django.urls import path

urlpatterns = [
    path('index/',views.about, name='index'),
]